                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1862680
Filament duck 750gr. spools by ColorFabb is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This remix of the Filament Duck enables it's use with colorFabb's 750gr. spools. 
We printed this model in nGen with various colors.

Also take a look at our remix to fit the colorFabb 2,2kg. spools, which is ideal for our Economy PLA line: <a href="http://www.thingiverse.com/thing:1862683">Thing:1862683</a>



# Print Settings

Printer Brand: LulzBot
Printer: Mini
Rafts: No
Supports: No
Resolution: 0.2
Infill: 20% - 30%

Notes: 
As this is quite a big print, we used the Lulzbot's 0,5mm nozzle to speed things up a bit.

# How I Designed This

We only scaled this model to accommodate the specific size of our 750gr. spool.
The original design was made by <a href="http://www.thingiverse.com/bold/about">bold</a> and all credits go to him.
                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1862683
Filament duck 2.2kg spools by ColorFabb is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This remix of the Filament Duck enables it's use with colorFabb's 2.2kg XL spools. We printed this model in our <a href="http://colorfabb.com/economy">Economy PLA</a>, which is supplied on the 2,2kg spools that this model is made for.

Also take a look at our remix to fit the colorFabb 750gr. spools: <a href="http://www.thingiverse.com/thing:1862680">thing:1862680</a>

# Print Settings

Printer Brand: Ultimaker
Printer: Ultimaker 2
Rafts: No
Supports: No
Resolution: 0.2
Infill: 20% - 30%

Notes: 
As this is quite a big print, we used a 0,6mm nozzle to speed things up a bit.

# How I Designed This

We only scaled this model to accommodate the specific size of our 2,2kg spool.
The original design was made by <a href="http://www.thingiverse.com/bold/about">bold</a> and all credits go to him.